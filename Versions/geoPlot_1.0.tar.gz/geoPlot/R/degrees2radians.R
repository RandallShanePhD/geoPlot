degrees2radians <-
function(x){
	radians <- (x * 0.0174532925)
	return( radians)}

