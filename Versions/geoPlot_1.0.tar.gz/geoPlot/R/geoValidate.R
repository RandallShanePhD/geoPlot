geoValidate <-
function(x){
	valid <- if(x[17]== 'list(c("0", "0"))') FALSE else TRUE
	return(valid)}

